import React from 'react';

function Home(){
    return(
        <div>
            <nav>
                <h2>My App</h2>
            </nav>
        </div>
    )
}

export default Home;