import React from 'react';


function Footer(){
    return(
        <footer>
            <span>Copyright &copy; 2023</span>
            <span> Spontan Uhuyyy</span>
        </footer>    
    )
}

export default Footer;